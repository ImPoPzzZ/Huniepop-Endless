# Dev notes — status & open work

## v0.1 — spine + first catalog (built, UNTESTED in-game)

Everything below compiles and auto-installs. None of it has run inside HuniePop 2 yet —
the first playtest will almost certainly turn up timing/NRE issues around the scene
bootstrap and the draft trigger.

### Works on paper
- Title "ENDLESS" button + difficulty launch screen + "Are you sure?" confirm.
- Synthetic level-0 PlayerFile in memory slot 3; `SaveGuard` blocks all 4 persistence
  writers while `EndlessRun.Active`.
- Bootstrap departs to a random date location → HP2's native Non-Stop path does the rest.
- `DateFlowPatch`: counts cleared dates, ramps the goal, rewrites the move budget
  (`20 + 15·N + card mods`), reroutes Non-Stop failure to the title summary.
- Draft: blurred/click-blocked backdrop, 3 weighted cards, confirm, apply. ~25 cards
  across moves / affection / sentiment / passion / stamina / token-weight / permanent
  levels / baggage-trade / date-gifts / puzzle-offsets.
- `GiftPicker` sequential girl-choice modal.
- `RunHooks` re-adds perma-baggage and recurring gifts each round.

### Known gaps / TODO
1. **Playtest the bootstrap.** `RunBootstrap.Tick` waits for `!Location.isLocked` then
   `Depart`. If the initial apartment arrival never unlocks, or `dateLocationsInfos` is
   empty at that point, date 1 won't start. Add fallbacks / logging as needed.
2. **Draft timing.** Pump opens the draft when `grid.state == WAITING && !isCutscenePlaying`.
   Verify it lands after the banter and that freezing time via the puzzle pause def
   doesn't wedge anything.
3. **Heartbreak-lover detection is stubbed** (`HeartbreakLover.IsLover` → always false).
   Implement: scan a girl's `baggageItemDefs[i].ailmentDefinition` steps for a
   `MatchModifier.replaceDefinition` that turns BROKEN into passion/affection, or the
   `brokenProtectionAilmentDefinition`. Populate `EndlessRun.HeartbreakLovers` at roster
   time. Show the ♥̸ tag. Wire the "matches give her passion / passion hearts make her
   mad" inversion (deep — match-reward level).
4. **Mid-run location/time change** only re-skins the background (`AdvanceLocationForRound`).
   The full "girls leave → date card → new banter" transition between dates is not done.
5. **Perma-baggage overflow** (past 4/girl) currently applies a permanent
   `power_token_chance -1` as a stand-in for "−10 passion FOREVER". Revisit.
6. **`pass_stat`** (permanent passion multiplier) card was dropped — HP2 computes the
   multiplier from `receivedUniques.Count`, no clean setter. Could pad that list.
7. **No HUD yet** — no on-screen date #, goal, or active-modifier readout. `EndlessHud`
   is planned in the design doc, not built.
8. **Balance is untuned.** Goal ramp is HP2's native `250 + 250·N` with level-0 girls;
   date 1 with 20 moves may be very hard. Tune `DateFlowPatch` / catalog numbers after
   the first real run.
9. **Blur** is a screen-grab downsample (no shader). Looks soft; fine.
10. Token-weight cards apply board-wide and persist for the run (Non-Stop never rebuilds
    `tokenStatus`). The heartbreak-lover swap is decided from the *current* pair at draft
    time, not re-evaluated per date.

## Longer list of the user's power-up ideas not yet in the catalog
- `+3 stamina every 5 moves` style regen riders (partially — `stam_regen` id reserved,
  not implemented; needs a per-move Harmony hook on the grid).
- stamina drain riders (`−1 stamina every N moves`).
- flat `±20` token nudges (only `±%` implemented).
- "max out a chosen girl's baggage this date but start at 25% goal".
- 3-random-date-gift bundle exists (`gift_bundle`); the "+50% broken hearts" swap card
  needs the heartbreak-lover system first.
