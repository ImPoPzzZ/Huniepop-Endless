# Huniepop Endless

A BepInEx roguelite mode for **HuniePop 2 – Double Date**. An "ENDLESS" button on the
title screen drops you straight into an unbroken chain of Non-Stop dates: the affection
goal climbs every date, you keep your moves between dates, and before each date you draft
one of three random power-ups. Fail a date and the run is over. **Nothing is saved** — the
run lives entirely in memory.

## Build

Requires the .NET SDK. Edit `<GameRoot>` in `HuniepopEndless.csproj` if your install
isn't at the default Steam path, then:

```
dotnet build
```

The DLL is copied into `…/HuniePop 2 - Double Date/BepInEx/plugins/HuniepopEndless/`
automatically on every build. Launch the game and read `BepInEx/LogOutput.log`.

## How a run works

1. **Title → ENDLESS** → pick a difficulty → confirm.
2. A throwaway save file (slot 3, memory only) is built at level 0 and MainScene loads.
3. `RunBootstrap` departs to a random date location; HuniePop 2's own Non-Stop machinery
   takes over (shuffle roster, escalating goal, intro banter, start puzzle).
4. When the banter ends, the **draft** opens over a blurred, click-blocked screen: three
   cards, pick one, confirm.
5. Clear the date → next date (goal +250, `moves = 20 + 15·datesCleared + card mods`,
   time of day advances Morning→Afternoon→Evening→Night, new location, new draft).
6. Fail a date → summary → back to the title. Save files on disk are never touched.

## Source map

| File | Role |
|---|---|
| `EndlessPlugin` | BepInEx entry, Harmony bootstrap, per-frame pump |
| `EndlessRun` | whole-run state (memory only) |
| `TitleMenuPatch` / `EndlessLauncher` | the ENDLESS button and its launch screen |
| `SaveGuard` | blocks every `GamePersistence` write during a run |
| `RunBootstrap` | starts date 1, cycles location/time, ends the run |
| `DateFlowPatch` | date counting, goal ramp, move budget, failure → title |
| `RunHooks` | re-applies per-run modifiers HP2 rebuilds each round (baggage, gifts) |
| `PowerUpCatalog` / `PowerUp` | the card list + weighted draw |
| `PowerUpDraft` | the draft UI |
| `GiftPicker` | "which girl gets this gift" modal |
| `BaggageService` / `HeartbreakLover` | baggage cap logic; heartbreak-lover detection |
| `SummaryPanel` | end-of-run screen |
| `UiKit` / `ConfirmDialog` | uGUI helpers, blurred backdrop, confirm modal |

See `NOTES.md` for what still needs testing and tuning.
